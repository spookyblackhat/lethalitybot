const Discord = require('discord.js')
const settings = require("../settings/configuration").BOT_SETTINGS

module.exports = {
    execute: async(client, member) => {},
    name: "guildMemberAdd",
};